# Blob.io
## How to run ##

To run the game you first have to download all the dependencies. Run **npm install** and then **npm run start-with-server**. Navigate to **http://localhost** to play the game!

## Video ##

The video demo for the game is located in **demo/**.

## Report ##

The report for the game is located in **documentation/**.
