module.exports = {
    MAX_RADIUS_BEFORE_ZOOMING: 120
}